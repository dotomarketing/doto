const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const { Pool } = require("pg");
const { ethers } = require("ethers");
require("dotenv").config();

const app = express();
app.use(helmet());
app.use(express.json({ limit: "10kb" }));

if (!process.env.DATABASE_URL) throw new Error("DATABASE_URL is missing");
if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) throw new Error("JWT_SECRET must be at least 32 characters");

const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: { rejectUnauthorized: false } });
const allowedOrigins = (process.env.FRONTEND_URL || "").split(",").map(x => x.trim()).filter(Boolean);
app.use((req, res, next) => {
  const origin = req.headers.origin;
  if (origin && allowedOrigins.includes(origin)) {
    res.setHeader("Access-Control-Allow-Origin", origin);
    res.setHeader("Vary", "Origin");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  }
  if (req.method === "OPTIONS") return res.sendStatus(204);
  next();
});

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: "draft-7", legacyHeaders: false, message: { error: "تعداد تلاش‌ها زیاد است. کمی بعد دوباره امتحان کنید." } });
const financeLimiter = rateLimit({ windowMs: 60 * 60 * 1000, limit: 15, standardHeaders: "draft-7", legacyHeaders: false, message: { error: "درخواست‌های مالی بیش از حد مجاز است. بعداً تلاش کنید." } });
const BSC_CHAIN_ID = 56;
const USDT_CONTRACT = ethers.getAddress(process.env.USDT_CONTRACT || "0x55d398326f99059fF775485246999027B3197955");
const DEPOSIT_ADDRESS = ethers.getAddress(process.env.DEPOSIT_ADDRESS || "0x9808490724F8BE320FfA3E904De11e3718ab30A4");
const TOKEN_DECIMALS = 18; // Binance-Peg BSC-USD uses 18 decimals on BNB Smart Chain.
const DOTO_PRICE_NUMERATOR = 17n; // 0.017 USDT = 17 / 1000
const DOTO_PRICE_DENOMINATOR = 1000n;
const TRANSFER_TOPIC = ethers.id("Transfer(address,address,uint256)");
const transferInterface = new ethers.Interface(["event Transfer(address indexed from, address indexed to, uint256 value)"]);

function createToken(user) {
  return jwt.sign({ id: user.id, username: user.username }, process.env.JWT_SECRET, { expiresIn: "1h" });
}
function authenticate(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: "ابتدا وارد حساب شوید." });
  try { req.user = jwt.verify(token, process.env.JWT_SECRET); next(); }
  catch { return res.status(401).json({ error: "نشست شما معتبر نیست." }); }
}
function decimalToRaw(value) {
  if (typeof value !== "string" && typeof value !== "number") throw new Error("مبلغ نامعتبر است.");
  const s = String(value).trim();
  if (!/^\d{1,12}(\.\d{1,18})?$/.test(s)) throw new Error("مبلغ نامعتبر است.");
  return ethers.parseUnits(s, TOKEN_DECIMALS);
}
function rawToDecimal(raw) { return ethers.formatUnits(BigInt(raw), TOKEN_DECIMALS); }
function randomUniqueMicroAmount(baseRaw) {
  // Add 1..999999 smallest 6-decimal USDT units (1e12 token base units) to uniquely identify each request.
  return baseRaw + BigInt(1 + Math.floor(Math.random() * 999)) * 1000000000000n;
}

async function initializeDatabase() {
  await pool.query(`CREATE TABLE IF NOT EXISTS users (
    id BIGSERIAL PRIMARY KEY, username VARCHAR(30) NOT NULL UNIQUE,
    email VARCHAR(255) NOT NULL UNIQUE, password_hash TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
  )`);
  await pool.query(`ALTER TABLE users ADD COLUMN IF NOT EXISTS referral_code VARCHAR(20)`);
  await pool.query(`ALTER TABLE users ADD COLUMN IF NOT EXISTS referred_by BIGINT REFERENCES users(id) ON DELETE SET NULL`);
  await pool.query(`ALTER TABLE users ADD COLUMN IF NOT EXISTS usdt_balance NUMERIC(36,18) NOT NULL DEFAULT 0`);
  await pool.query(`ALTER TABLE users ADD COLUMN IF NOT EXISTS doto_balance NUMERIC(36,18) NOT NULL DEFAULT 0`);
  await pool.query(`UPDATE users SET referral_code = 'DOTO' || UPPER(SUBSTRING(MD5(RANDOM()::TEXT || id::TEXT || CLOCK_TIMESTAMP()::TEXT) FROM 1 FOR 10)) WHERE referral_code IS NULL`);
  await pool.query(`CREATE UNIQUE INDEX IF NOT EXISTS users_referral_code_unique ON users(referral_code)`);
  await pool.query(`CREATE TABLE IF NOT EXISTS deposit_requests (
    id BIGSERIAL PRIMARY KEY, user_id BIGINT NOT NULL REFERENCES users(id),
    sender_address VARCHAR(42) NOT NULL, requested_amount NUMERIC(36,18) NOT NULL,
    amount_raw NUMERIC(78,0) NOT NULL UNIQUE, status VARCHAR(20) NOT NULL DEFAULT 'pending',
    tx_hash VARCHAR(66) UNIQUE, block_number BIGINT, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    confirmed_at TIMESTAMPTZ
  )`);
  await pool.query(`CREATE INDEX IF NOT EXISTS deposit_requests_match_idx ON deposit_requests(sender_address, status, created_at)`);
  await pool.query(`CREATE TABLE IF NOT EXISTS ledger (
    id BIGSERIAL PRIMARY KEY, user_id BIGINT NOT NULL REFERENCES users(id),
    kind VARCHAR(20) NOT NULL, asset VARCHAR(10) NOT NULL, amount NUMERIC(36,18) NOT NULL,
    reference VARCHAR(100) NOT NULL UNIQUE, details JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  )`);
  await pool.query(`CREATE TABLE IF NOT EXISTS scanner_state (id INTEGER PRIMARY KEY CHECK (id=1), last_scanned_block BIGINT NOT NULL)`);
}

app.get("/api/health", (req, res) => res.json({ status: "ok", service: "DOTO API", chainId: BSC_CHAIN_ID, depositWatcher: Boolean(process.env.BSC_RPC_URL) }));

app.post("/api/auth/register", authLimiter, async (req, res) => {
  try {
    const { username, email, password } = req.body;
    if (typeof username !== "string" || typeof email !== "string" || typeof password !== "string") return res.status(400).json({ error: "اطلاعات نامعتبر است." });
    const cleanUsername = username.trim(), cleanEmail = email.trim().toLowerCase();
    if (!/^[a-zA-Z0-9_]{3,30}$/.test(cleanUsername)) return res.status(400).json({ error: "نام کاربری باید ۳ تا ۳۰ حرف و شامل حروف انگلیسی، عدد یا _ باشد." });
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail) || cleanEmail.length > 255) return res.status(400).json({ error: "ایمیل معتبر نیست." });
    if (password.length < 12 || password.length > 72) return res.status(400).json({ error: "رمز عبور باید حداقل ۱۲ و حداکثر ۷۲ کاراکتر باشد." });
    const passwordHash = await bcrypt.hash(password, 12);
    const result = await pool.query(`INSERT INTO users (username,email,password_hash) VALUES ($1,$2,$3) RETURNING id,username,email,created_at`, [cleanUsername, cleanEmail, passwordHash]);
    const user = result.rows[0];
    res.status(201).json({ message: "حساب کاربری ساخته شد.", token: createToken(user), user });
  } catch (e) {
    if (e.code === "23505") return res.status(409).json({ error: "این نام کاربری یا ایمیل قبلاً ثبت شده است." });
    console.error("Register error:", e.message); res.status(500).json({ error: "خطای داخلی سرور." });
  }
});
app.post("/api/auth/login", authLimiter, async (req, res) => {
  try {
    const { email, password } = req.body;
    if (typeof email !== "string" || typeof password !== "string") return res.status(400).json({ error: "اطلاعات ورود نامعتبر است." });
    const result = await pool.query(`SELECT id,username,email,password_hash,created_at FROM users WHERE email=$1`, [email.trim().toLowerCase()]);
    const user = result.rows[0];
    if (!user || !(await bcrypt.compare(password, user.password_hash))) return res.status(401).json({ error: "ایمیل یا رمز عبور اشتباه است." });
    res.json({ message: "ورود موفق بود.", token: createToken(user), user: { id:user.id, username:user.username, email:user.email, created_at:user.created_at } });
  } catch (e) { console.error("Login error:",e.message); res.status(500).json({ error:"خطای داخلی سرور." }); }
});
app.get("/api/auth/me", authenticate, async (req,res) => {
  try { const r=await pool.query(`SELECT id,username,email,created_at,usdt_balance,doto_balance FROM users WHERE id=$1`,[req.user.id]); if(!r.rows[0]) return res.status(404).json({error:"کاربر پیدا نشد."}); res.json({user:r.rows[0]}); }
  catch(e){console.error(e.message);res.status(500).json({error:"خطای داخلی سرور."});}
});

app.get("/api/finance/config", authenticate, (req,res) => res.json({ chainId:BSC_CHAIN_ID, chainName:"BNB Smart Chain", network:"BEP-20", token:"USDT", tokenContract:USDT_CONTRACT, depositAddress:DEPOSIT_ADDRESS, tokenDecimals:TOKEN_DECIMALS, dotoPrice:"0.017", withdrawalsEnabled:false }));
app.get("/api/finance/summary", authenticate, async (req,res) => {
  try { const r=await pool.query(`SELECT usdt_balance,doto_balance FROM users WHERE id=$1`,[req.user.id]); if(!r.rows[0]) return res.status(404).json({error:"کاربر پیدا نشد."}); res.json(r.rows[0]); }
  catch(e){console.error(e.message);res.status(500).json({error:"خطای داخلی سرور."});}
});
app.post("/api/deposits/request", authenticate, financeLimiter, async (req,res) => {
  try {
    const sender=ethers.getAddress(String(req.body.senderAddress||""));
    const desiredRaw=decimalToRaw(req.body.amount);
    if(desiredRaw < ethers.parseUnits("1",TOKEN_DECIMALS)) return res.status(400).json({error:"حداقل مبلغ واریز ۱ USDT است."});
    // Unique exact transfer amount makes shared-wallet deposits attributable; sender address is also matched.
    let exactRaw, inserted;
    for(let i=0;i<8;i++){
      exactRaw=randomUniqueMicroAmount(desiredRaw);
      try { inserted=await pool.query(`INSERT INTO deposit_requests(user_id,sender_address,requested_amount,amount_raw) VALUES($1,$2,$3,$4) RETURNING id,requested_amount,created_at`,[req.user.id,sender,rawToDecimal(exactRaw),exactRaw.toString()]); break; }
      catch(e){if(e.code!=="23505"||i===7) throw e;}
    }
    res.status(201).json({requestId:inserted.rows[0].id, exactAmount:rawToDecimal(exactRaw), requestedAmount:String(req.body.amount), senderAddress:sender, depositAddress:DEPOSIT_ADDRESS, network:"BNB Smart Chain (BEP-20)", status:"pending", note:"دقیقاً همین مبلغ را از همان آدرس ثبت‌شده ارسال کنید. پس از تأیید شبکه، موجودی خودکار شارژ می‌شود."});
  } catch(e){ if(e.code==="INVALID_ARGUMENT") return res.status(400).json({error:"آدرس کیف پول فرستنده معتبر نیست."}); console.error("Deposit request:",e.message);res.status(400).json({error:e.message||"ثبت درخواست واریز ناموفق بود."}); }
});
app.get("/api/deposits", authenticate, async(req,res)=>{
  try{const r=await pool.query(`SELECT id,requested_amount,sender_address,status,tx_hash,created_at,confirmed_at FROM deposit_requests WHERE user_id=$1 ORDER BY id DESC LIMIT 30`,[req.user.id]);res.json({deposits:r.rows});}
  catch(e){console.error(e.message);res.status(500).json({error:"خطای داخلی سرور."});}
});
app.post("/api/purchases", authenticate, financeLimiter, async(req,res)=>{
  const client=await pool.connect();
  try{
    const spendRaw=decimalToRaw(req.body.usdtAmount);
    if(spendRaw<=0n) return res.status(400).json({error:"مبلغ خرید نامعتبر است."});
    const dotoRaw=(spendRaw*DOTO_PRICE_DENOMINATOR)/DOTO_PRICE_NUMERATOR;
    if(dotoRaw<=0n) return res.status(400).json({error:"مبلغ خرید بسیار کم است."});
    await client.query("BEGIN");
    const u=await client.query(`SELECT usdt_balance FROM users WHERE id=$1 FOR UPDATE`,[req.user.id]);
    if(!u.rows[0]) throw new Error("کاربر پیدا نشد.");
    const balanceRaw=decimalToRaw(String(u.rows[0].usdt_balance));
    if(balanceRaw<spendRaw){await client.query("ROLLBACK");return res.status(400).json({error:"موجودی USDT کافی نیست."});}
    const spend=rawToDecimal(spendRaw), doto=rawToDecimal(dotoRaw);
    await client.query(`UPDATE users SET usdt_balance=usdt_balance-$1::numeric,doto_balance=doto_balance+$2::numeric WHERE id=$3`,[spend,doto,req.user.id]);
    const ref=`purchase:${ethers.hexlify(ethers.randomBytes(16))}`;
    await client.query(`INSERT INTO ledger(user_id,kind,asset,amount,reference,details) VALUES($1,'purchase','DOTO',$2,$3,$4::jsonb)`,[req.user.id,doto,ref,JSON.stringify({usdtSpent:spend,price:"0.017"})]);
    const updated=await client.query(`SELECT usdt_balance,doto_balance FROM users WHERE id=$1`,[req.user.id]);
    await client.query("COMMIT");res.json({message:"خرید DOTO با موفقیت انجام شد.",usdtSpent:spend,dotoReceived:doto,balances:updated.rows[0]});
  }catch(e){await client.query("ROLLBACK");console.error("Purchase error:",e.message);res.status(400).json({error:e.message||"خرید انجام نشد."});}
  finally{client.release();}
});
app.get("/api/ledger",authenticate,async(req,res)=>{
  try{const r=await pool.query(`SELECT kind,asset,amount,reference,details,created_at FROM ledger WHERE user_id=$1 ORDER BY id DESC LIMIT 50`,[req.user.id]);res.json({items:r.rows});}
  catch(e){console.error(e.message);res.status(500).json({error:"خطای داخلی سرور."});}
});

let watcherBusy=false;
async function scanDeposits(provider){
  if(watcherBusy)return; watcherBusy=true;
  try{
    const latest=await provider.getBlockNumber();
    const confirmations=Math.max(1,Number(process.env.BSC_CONFIRMATIONS||15));
    const safeLatest=latest-confirmations;
    const state=await pool.query(`SELECT last_scanned_block FROM scanner_state WHERE id=1`);
    if(!state.rows.length){await pool.query(`INSERT INTO scanner_state(id,last_scanned_block) VALUES(1,$1) ON CONFLICT(id) DO NOTHING`,[Math.max(0,safeLatest-20)]);return;}
    let from=Number(state.rows[0].last_scanned_block)+1;
    if(from>safeLatest)return;
    const to=Math.min(safeLatest,from+Math.max(1,Number(process.env.BSC_SCAN_BLOCK_RANGE||500))-1);
    const logs=await provider.getLogs({address:USDT_CONTRACT,fromBlock:from,toBlock:to,topics:[TRANSFER_TOPIC,null,ethers.zeroPadValue(DEPOSIT_ADDRESS,32)]});
    for(const log of logs){
      let parsed;try{parsed=transferInterface.parseLog(log);}catch{continue;}
      const sender=ethers.getAddress(parsed.args.from);
      const amountRaw=BigInt(parsed.args.value);
      const block=await provider.getBlock(log.blockNumber);
      const blockTime=new Date(Number(block.timestamp)*1000);
      const client=await pool.connect();
      try{
        await client.query("BEGIN");
        const existing=await client.query(`SELECT id FROM deposit_requests WHERE tx_hash=$1`,[log.transactionHash]);
        if(existing.rows.length){await client.query("COMMIT");continue;}
        const match=await client.query(`SELECT id,user_id FROM deposit_requests WHERE status='pending' AND sender_address=$1 AND amount_raw=$2 AND created_at <= $3::timestamptz + interval '60 seconds' ORDER BY id ASC LIMIT 1 FOR UPDATE`,[sender,amountRaw.toString(),blockTime.toISOString()]);
        if(match.rows.length){
          const dep=await client.query(`UPDATE deposit_requests SET status='confirmed',tx_hash=$1,block_number=$2,confirmed_at=NOW() WHERE id=$3 AND status='pending' RETURNING user_id,requested_amount`,[log.transactionHash,log.blockNumber,match.rows[0].id]);
          if(dep.rows.length){
            const amount=String(dep.rows[0].requested_amount);
            await client.query(`UPDATE users SET usdt_balance=usdt_balance+$1::numeric WHERE id=$2`,[amount,dep.rows[0].user_id]);
            await client.query(`INSERT INTO ledger(user_id,kind,asset,amount,reference,details) VALUES($1,'deposit','USDT',$2,$3,$4::jsonb) ON CONFLICT(reference) DO NOTHING`,[dep.rows[0].user_id,amount,`deposit:${log.transactionHash}`,JSON.stringify({txHash:log.transactionHash,blockNumber:log.blockNumber,from:sender})]);
          }
        }
        await client.query("COMMIT");
      }catch(e){await client.query("ROLLBACK");throw e;}finally{client.release();}
    }
    await pool.query(`UPDATE scanner_state SET last_scanned_block=$1 WHERE id=1`,[to]);
  }catch(e){console.error("BSC watcher error:",e.message);}finally{watcherBusy=false;}
}

const PORT=process.env.PORT||10000;
initializeDatabase().then(async()=>{
  app.listen(PORT,"0.0.0.0",()=>console.log(`DOTO API running on port ${PORT}`));
  if(process.env.BSC_RPC_URL){
    const provider=new ethers.JsonRpcProvider(process.env.BSC_RPC_URL, BSC_CHAIN_ID);
    try{const network=await provider.getNetwork();if(Number(network.chainId)!==BSC_CHAIN_ID)throw new Error("BSC_RPC_URL is not connected to BNB Smart Chain mainnet");
      console.log("BSC USDT watcher enabled");
      await scanDeposits(provider);setInterval(()=>scanDeposits(provider),Number(process.env.BSC_SCAN_INTERVAL_MS||15000));
    }catch(e){console.error("BSC watcher could not start:",e.message);}
  }else console.warn("BSC_RPC_URL is missing: on-chain deposits are NOT being monitored.");
}).catch(e=>{console.error("Database initialization failed:",e.message);process.exit(1);});
